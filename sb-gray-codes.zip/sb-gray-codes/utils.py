from datetime import datetime
import matplotlib.pyplot as plt

from stats import RunStats


def visualize_stats(multiple_run_stats, color, label):

    plt.xlabel("Time (seconds)")
    plt.ylabel("properly placed codes")
    for run_stats in multiple_run_stats:
        iterations, seconds, values = split_to_iters_time_and_values(run_stats)
        plt.plot(seconds, values, "{}--".format(color), label=label)


def get_avg_iterations(mutliple_run_iterations):

    iterations_sum = 0
    for run_iterations in mutliple_run_iterations:
        iterations_sum += len(run_iterations)
    return float(iterations_sum) / float(len(mutliple_run_iterations))


def get_avg_seconds(mutliple_run_stats):

    time_sum = 0
    for run_stats in mutliple_run_stats:
        time_sum += run_stats.run_time()
    return float(time_sum) / float(len(mutliple_run_stats))


def split_to_iters_time_and_values(run_stats):

    return zip(*[(stat.iteration, stat.seconds, stat.value) for stat in run_stats])


class Duplicatecode(Exception):
    pass


class codeOutOfcodecode(Exception):
    pass


class codecodeIsEmpty(Exception):
    pass


def log(message):
    print("{} | {}".format(datetime.now(), message))


def run_multiple_times(times, function, params):

    multiple_run_stats = []
    for i in range(0, times):
        code, stats = function(*params)
        multiple_run_stats.append(RunStats(params[0], code, params[2], stats))
    return multiple_run_stats


def display_codecode(codes, codeSIZE):

    print("".join(["-"] * ((codeSIZE * 3) + 2)))
    for y in range(0, codeSIZE):
        row = []
        for x in range(0, codeSIZE):
            codes_on_pos = filter(lambda code: code.x == x and code.y == y, codes)
            row.append(" - " if not codes_on_pos else " X ")
        print(" {}|{}".format(y, "".join(row)) if y <= 9 else "{}|{}".format(y, "".join(row)))
    print("".join(["-"] * ((codeSIZE * 3) + 2)))


def seconds_since(start_time):

    return (datetime.now() - start_time).total_seconds()


def are_codes_on_diagonal(first_code, second_code):

    return abs(second_code.x - first_code.x) == abs(second_code.y - first_code.y)
