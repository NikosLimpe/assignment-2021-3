from random import shuffle

import operator

from model import code
from utils import are_codes_on_diagonal, log


def get_all_positions(existing_codes, code_size):

    possible_codes = set()
    for x in range(0, code_size):
        for y in range(0, code_size):
            possible_codes.add(code(x, y))
    possible_codes = list(possible_codes)
    shuffle(possible_codes)
    return possible_codes


def get_free_positions(existing_codes, code_size):

    all_positions = set(get_all_positions([], code_size))
    possible_codes = list(all_positions - set(existing_codes))
    shuffle(possible_codes)
    return possible_codes


def get_not_conflicted_positions_sorted_by_efficiency(existing_codes, code_size):

    available_codes = get_not_conflicted_positions(existing_codes, code_size)
    available_code_to_taken_slots = _build_available_code_to_efficiency_dict(existing_codes, available_codes,
                                                                               code_size)
    available_codes_sorted_by_efficiency = sorted(available_code_to_taken_slots.items(), key=operator.itemgetter(1))
    available_codes_sorted_by_efficiency.reverse()
    return [code for code, efficiency in available_codes_sorted_by_efficiency]


def _build_available_code_to_efficiency_dict(existing_codes, available_codes, n):

    return {avail_code: len(get_not_conflicted_positions(existing_codes + [avail_code], n)) for avail_code in
            available_codes}


def get_not_conflicted_positions(existing_codes, code_size):

    possible_codes = list(get_all_positions([], code_size=code_size))
    for existing in existing_codes:
        possible_codes = filter(
            lambda possible:
            possible.x != existing.x
            and possible.y != existing.y
            and not are_codes_on_diagonal(existing, possible),
            possible_codes)
    shuffle(possible_codes)
    return possible_codes
